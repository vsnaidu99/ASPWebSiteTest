import {createSelector } from 'reselect';
import { getNewsList, getFilter } from './news.reducer';

export const getNews = '';
