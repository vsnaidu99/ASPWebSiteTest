import { getNews } from "./../../store/reducers/selector";
import { initialState } from "./../../store/reducers/news.reducer";
import { Component, OnInit } from "@angular/core";
import { Store, State } from "@ngrx/store";
import { sections } from "../../store/reducers/sections.reducer";
import { Observable } from "rxjs/Observable";
import { News } from "../../model/news";

@Component({
  selector: "app-sections",
  templateUrl: "./sections.component.html",
  styleUrls: ["./sections.component.css"],
})



export class SectionsComponent {
  sectionList: any;
  constructor(private store: Store<News>) {
    store.select('sections')
      // .subscribe( (sectionList:News ) => {
      //   this.sectionList = sectionList.section; 
      //   console.log(sectionList);
      // });
      .subscribe(
        (res: any) => {
          this.sectionList =res; 
          console.log("result", this.sectionList);
        })
  }
}
