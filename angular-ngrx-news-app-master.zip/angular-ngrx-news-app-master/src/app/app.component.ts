import { Component } from '@angular/core';

@Component({
  selector: 'nyt-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'News App | Angular with NgRx';
}
